import ast
import json
import os

import jwt
from flask import Flask, request, jsonify, render_template, current_app, session
from flask_cors import CORS
from werkzeug.utils import secure_filename

from auth import auth_bp
from des.DES import DES
from des.modes_runner import run_des
from des.utils import ensure_hex, hex_to_text, left_circ_shift
from extensions import db, bcrypt
from models import History

app = Flask(__name__)
app.config.update(
    SQLALCHEMY_DATABASE_URI='sqlite:///users.db',
    SQLALCHEMY_TRACK_MODIFICATIONS=False,
    SECRET_KEY='supersecretkey',
)
CORS(app, resources={r'/*': {'origins': 'http://localhost:5000'}}, supports_credentials=True)

db.init_app(app)
bcrypt.init_app(app)

# Register your auth blueprint (login/register/profile/history)
app.register_blueprint(auth_bp)

with app.app_context():
    db.create_all()


@app.context_processor
def inject_current_user():
    token = request.cookies.get("token")
    if not token:
        return dict(current_user_id=None)

    try:
        payload = jwt.decode(token, current_app.config["SECRET_KEY"],
                             algorithms=["HS256"])
        return dict(current_user_id=payload.get("user_id"))
    except jwt.InvalidTokenError:
        return dict(current_user_id=None)


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/encrypt', methods=['POST'])
def encrypt():
    data = request.get_json()
    message = data.get('message', '')
    hex_key = data.get('hex_key', '')
    mode = data.get('mode', 'ECB').upper()

    # Validate inputs
    if not message or not hex_key:
        return jsonify(error='Message and hex_key are required'), 400
    if len(hex_key) != 16 or any(c not in '0123456789abcdefABCDEF' for c in hex_key):
        return jsonify(error='DES key must be 16 hex chars (64-bit including parity)'), 400

    try:
        # Prepare and run DES
        hex_message = ensure_hex(message)
        result = run_des('encrypt', mode, hex_message, hex_key)

        # Unpack result
        if len(result) == 3:
            cipher_hex, rounds, keys = result
            extra = None
        else:
            cipher_hex, extra, rounds, keys = result

        # Save to history if user is logged in
        token = request.cookies.get('token')
        if token:
            try:
                payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
                user_id = payload["user_id"]
                h = History(
                    operation='encrypt',
                    mode=mode,
                    message_input=message,
                    key_input=hex_key,
                    extra_param=extra,
                    encrypted_message=cipher_hex,
                    decrypted_message=message,
                    user_id=user_id
                )
                db.session.add(h)
                db.session.commit()
            except jwt.InvalidTokenError:
                pass

        # Store round‐1 data & key for detail view
        session['last_mode'] = 'encrypt'
        session['last_round_data'] = rounds[0]
        session['last_hex_key'] = hex_key
        session['last_key'] = keys[0]

        return jsonify(
            encrypted_hex=cipher_hex,
            round_results=rounds,
            key_expansions=keys,
            extra=extra
        )
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/decrypt', methods=['POST'])
def decrypt():
    data = request.get_json(force=True)
    hex_message = data.get('hex_message', '')
    hex_key = data.get('hex_key', '')
    mode = data.get('mode', 'ECB').upper()

    # Validate inputs
    if not hex_message or not hex_key:
        return jsonify(error='hex_message and hex_key are required'), 400
    if any(c not in '0123456789abcdefABCDEF' for c in hex_message):
        return jsonify(error='hex_message must be valid hex'), 400
    if len(hex_key) != 16 or any(c not in '0123456789abcdefABCDEF' for c in hex_key):
        return jsonify(error='DES key must be 16 hex chars'), 400

    try:
        # Run DES decryption
        extra = data.get('extra', None)
        if extra:
            plain_hex, rounds, keys = run_des('decrypt', mode, hex_message, hex_key, extra)
        else:
            plain_hex, rounds, keys = run_des('decrypt', mode, hex_message, hex_key)

        # Try converting to printable text
        text_guess = hex_to_text(plain_hex)
        safe_text = text_guess if all(c.isprintable() or c.isspace() for c in text_guess) \
            else '[Non-text binary data]'

        # Save to history if user is logged in
        token = request.cookies.get('token')
        if token:
            try:
                payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
                user_id = payload["user_id"]
                h = History(
                    operation='decrypt',
                    mode=mode,
                    message_input=hex_message,
                    key_input=hex_key,
                    extra_param=extra,  # None for ECB
                    encrypted_message=hex_message,
                    decrypted_message=safe_text,
                    user_id=user_id
                )
                db.session.add(h)
                db.session.commit()
            except jwt.InvalidTokenError:
                pass

        # Store round‐1 data & key for detail view
        session['last_mode'] = 'decrypt'
        session['last_round_data'] = rounds[0]
        session['last_hex_key'] = hex_key
        session['last_key'] = keys[0]

        return jsonify(
            decrypted_text=safe_text,
            decrypted_hex=plain_hex,
            round_results=rounds,
            key_expansions=keys
        )
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/round1-details')
def round1_details():
    mode = session.get('last_mode')
    round_data = session.get('last_round_data')
    hex_key = session.get('last_hex_key')

    if not (mode and round_data and hex_key):
        return "No round data available. Please encrypt or decrypt first.", 400

    # Rebuild the key‐schedule through round 1
    des_obj = DES(hex_key)
    bin_key = DES.hex_to_bin(hex_key)  # 64-bit
    pc1_out = des_obj.PC_1.permutate(bin_key)  # 56-bit
    C0, D0 = pc1_out[:28], pc1_out[28:]  # split halves

    # Round-1 shift (always single-bit)
    C1 = left_circ_shift(C0, 1)
    D1 = left_circ_shift(D0, 1)

    pre_pc2 = C1 + D1
    round1_key_binary = des_obj.PC_2.permutate(pre_pc2)  # 48-bit
    round1_key_hex = hex(int(round1_key_binary, 2))[2:].upper().zfill(12)

    key_schedule = {
        'original_key_binary': bin_key,
        'pc1_output': pc1_out,
        'C0': C0,
        'D0': D0,
        'C1': C1,
        'D1': D1,
        'pre_pc2': pre_pc2,
        'round1_key_binary': round1_key_binary,
        'round1_key_hex': round1_key_hex,
    }

    if isinstance(round_data, str):
        try:
            round_data = json.loads(round_data)
        except ValueError:
            try:
                round_data = ast.literal_eval(round_data)
            except Exception:
                # give the template *something* iterable
                round_data = {"value": round_data}

    return render_template(
        'round1_details.html',
        mode=mode,
        round_data=round_data,
        round_key=round1_key_hex,
        key_schedule=key_schedule
    )


# Temporary folder for uploads
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit


@app.route('/encrypt_file', methods=['POST'])
def encrypt_file():
    if 'file' not in request.files:
        return jsonify(error='No file part'), 400

    file = request.files['file']
    hex_key = request.form.get('hex_key', '')
    mode = request.form.get('mode', 'ECB').upper()

    if not file or file.filename == '':
        return jsonify(error='No selected file'), 400
    if not hex_key:
        return jsonify(error='hex_key is required'), 400
    if len(hex_key) != 16 or any(c not in '0123456789abcdefABCDEF' for c in hex_key):
        return jsonify(error='DES key must be 16 hex chars'), 400

    try:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        with open(filepath, 'rb') as f:
            file_bytes = f.read()

        hex_message = file_bytes.hex()

        # Encrypt
        result = run_des('encrypt', mode, hex_message, hex_key)
        if len(result) == 3:
            cipher_hex, rounds, keys = result
        else:
            cipher_hex, extra, rounds, keys = result

        cipher_bytes = bytes.fromhex(cipher_hex)

        # Save encrypted file
        encrypted_filename = f'encrypted_{filename}'
        encrypted_filepath = os.path.join(app.config['UPLOAD_FOLDER'], encrypted_filename)
        with open(encrypted_filepath, 'wb') as f:
            f.write(cipher_bytes)

        return jsonify(
            message='File encrypted successfully',
            encrypted_file=encrypted_filename,
            round_results=rounds,
            key_expansions=keys
        )
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route('/decrypt_file', methods=['POST'])
def decrypt_file():
    if 'file' not in request.files:
        return jsonify(error='No file part'), 400

    file = request.files['file']
    hex_key = request.form.get('hex_key', '')
    mode = request.form.get('mode', 'ECB').upper()
    extra = request.form.get('extra', None)

    if not file or file.filename == '':
        return jsonify(error='No selected file'), 400
    if not hex_key:
        return jsonify(error='hex_key is required'), 400
    if len(hex_key) != 16 or any(c not in '0123456789abcdefABCDEF' for c in hex_key):
        return jsonify(error='DES key must be 16 hex chars'), 400

    try:
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        with open(filepath, 'rb') as f:
            file_bytes = f.read()

        hex_message = file_bytes.hex()

        # Decrypt
        if extra:
            plain_hex, rounds, keys = run_des('decrypt', mode, hex_message, hex_key, extra)
        else:
            plain_hex, rounds, keys = run_des('decrypt', mode, hex_message, hex_key)

        plain_bytes = bytes.fromhex(plain_hex)

        # Save decrypted file
        decrypted_filename = f'decrypted_{filename}'
        decrypted_filepath = os.path.join(app.config['UPLOAD_FOLDER'], decrypted_filename)
        with open(decrypted_filepath, 'wb') as f:
            f.write(plain_bytes)

        return jsonify(
            message='File decrypted successfully',
            decrypted_file=decrypted_filename,
            round_results=rounds,
            key_expansions=keys
        )
    except Exception as e:
        return jsonify(error=str(e)), 500


# Run the app on localhost
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
