class NoneSwapper:
    @staticmethod
    def encrypt(binary: str) -> str:
        return binary

    @staticmethod
    def decrypt(binary: str) -> str:
        return binary
